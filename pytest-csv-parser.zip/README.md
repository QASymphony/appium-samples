# junit for java parser test

### Install required node modules 
```
`npm install`
```
### Execute test
```
`npm run test`
```