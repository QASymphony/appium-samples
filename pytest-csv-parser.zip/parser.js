/** 
 * Parsing CSV report
 */

"use strict";

const fs = require("fs");
const globby = require("globby");
const csvtojson = require("csvtojson");

const timestamp = new Date();

const PASSED = 'passed';
const FAILED = 'failed';

let packageJson = require("./package.json");

function buildTestResultByMethodName(obj) {
  let name = obj.name;
  let exe_start_date = new Date(timestamp);
  let exe_end_date = new Date(timestamp);
  exe_end_date.setSeconds(exe_start_date.getSeconds() + (parseInt(obj.duration || 0, 10)));

  let status = obj.status === PASSED ? PASSED : FAILED;
  let testCase = {
    status: status,
    name: name,
    attachments: [],
    exe_start_date: exe_start_date.toISOString(),
    exe_end_date: exe_end_date.toISOString(),
    automation_content: obj.id,
    test_step_logs: [{
      order: 0,
      status: status,
      description: obj.name,
      expected_result: obj.name
    }]
  };
  if (obj.status != PASSED) {
    let failedMsg = obj.message;
    testCase.attachments.push({
      name: `${obj.name}.txt`,
      data: Buffer.from(failedMsg).toString("base64"),
      content_type: "text/plain"
    });
  }
  return testCase;
}

function parseFile(fileName) {
  return new Promise((resolve, reject) => {
    csvtojson()
      .fromFile(fileName)
      .then((jsonObj) => {
        resolve(jsonObj);
      })
  });
}

async function parse(pathToTestResult, options) {
  console.log(` == Parser name: ${packageJson.name}, version ${packageJson.version} ==`);
  console.log("Path to test result: " + pathToTestResult);
  let resultFiles = [];
  if (-1 !== pathToTestResult.indexOf("*")) {
    resultFiles = globby.sync(pathToTestResult);
  } else if (fs.statSync(pathToTestResult).isFile()) {
    resultFiles.push(pathToTestResult);
  } else if (fs.statSync(pathToTestResult).isDirectory()) {
    let pattern = undefined;
    pathToTestResult = pathToTestResult.replace(/\\/g, "/");
    if (pathToTestResult[pathToTestResult.length - 1] === '/') {
      pattern = pathToTestResult + "**/*.csv";
    } else {
      pattern = pathToTestResult + "/**/*.csv";
    }
    resultFiles = globby.sync(pattern);
  }

  if (0 === resultFiles.length) {
    throw new Error(`Could not find any result log-file(s) in: ' + ${pathToTestResult}`);
  }

  let resultMap = new Map();
  let order = 1;
  for (let file of resultFiles) {
    console.log(`Parsing ${file} ...`);
    let testcases = undefined;
    try {
      testcases = await parseFile(file);
    } catch (error) {
      console.error(`Could not parse ${file}`, error);
      continue;
    }

    for (let tc of testcases) {
      let tcObj = buildTestResultByMethodName(tc);

      if (tcObj && !resultMap.has(tcObj.automation_content)) {
        tcObj.order = order++;
        resultMap.set(tcObj.automation_content, tcObj);
      }
    }
    console.log(`Finish parsing ${file}`);
  }
  return (Array.from(resultMap.values()));
};

module.exports = {
  parse: parse
};
